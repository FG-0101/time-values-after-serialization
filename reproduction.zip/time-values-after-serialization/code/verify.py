"""Check integer timestamps, profiles, and coverage using a separate implementation."""
from pathlib import Path
import argparse,collections,gzip,json,math
ap=argparse.ArgumentParser();ap.add_argument('native',type=Path);ap.add_argument('reference',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();assert not args.output.exists()
bell=[1]
for n in range(6):bell.append(sum(math.comb(n,k)*bell[k] for k in range(n+1)))
def read(path):
 out={};groups=collections.defaultdict(set);matrix_entries=0;trials=0
 with gzip.open(path/'rows.jsonl.gz','rt') as f:
  for raw in f:
   row=json.loads(raw);p=tuple(row['partition']);n=row['n'];gap=row['gap_seconds'];key=(row['key'],row['constructor'],n,p);assert key not in out
   assert len(p)==n and p[0]==0
   for i in range(1,n):assert 0<=p[i]<=max(p[:i])+1
   group=key[:3];groups[group].add(p)
   want=[[0 if a==b else gap for b in p] for a in p];assert row['before']['profile']==want;matrix_entries+=n*n
   for scheme,x in row['schemes'].items():
    payload=bytes.fromhex(x['payload_hex'])
    if scheme=='scope_envelope' or (scheme=='grouped_pickle' and row['constructor']=='no_cache'):q=p
    elif scheme=='individual_pickle' and row['constructor']=='no_cache':q=tuple(range(n))
    else:q=(0,)*n
    expected=[[0 if a==b else gap for b in q] for a in q];assert x['after']['profile']==expected,(key,scheme);matrix_entries+=n*n;trials+=1
    for name in ['profile','wall','offsets','timestamps']:
     assert x['matches'][name]==(x['after'][name]==row['before'][name])
    assert x['matches']['all_observations']==all(x['matches'][name] for name in ['profile','wall','offsets','timestamps'])
    assert x['matches']['timestamps']
    if scheme!='utc_timestamps':assert x['matches']['wall'] and x['matches']['offsets']
    if scheme=='scope_envelope':
     encoded=json.loads(payload);assert encoded['handle_count']==len(set(p));assert tuple(v['handle'] for v in encoded['values'])==p
   out[key]=row
 for group,ps in groups.items():assert len(ps)==bell[group[2]],group
 assert len(groups)==48 and len(out)==2224 and trials==11120
 summary=json.loads((path/'summary.json').read_text());assert summary['counts']=={'tuples':len(out),'transport_trials':trials}
 for label,g in summary['groups'].items():
  group=(g['key'],g['constructor'],g['n']);rr=[out[group+(p,)] for p in groups[group]];assert g['partitions']==len(rr)
  assert g['distinct_profiles']==len({json.dumps(x['before']['profile']) for x in rr})
  for scheme,counts in g['schemes'].items():
   for field,c in counts.items():assert c==sum(x['schemes'][scheme]['matches'][field.removesuffix('_preserved')] for x in rr)
 return out,matrix_entries,trials
native,checks1,trials1=read(args.native);ref,checks2,trials2=read(args.reference);assert native.keys()==ref.keys()
for key,a in native.items():
 b=ref[key];assert a['before']==b['before']
 for scheme,x in a['schemes'].items():assert x['after']==b['schemes'][scheme]['after'] and x['matches']==b['schemes'][scheme]['matches']
report={'status':'PASS','tuples_each':len(native),'transport_trials_each':trials1,'profile_entries_checked':checks1+checks2,'bell_numbers':bell[1:],'duplicate_rows':0,'native_reference_observation_disagreements':0}
args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
