"""Run the temporal transports over every finite sharing partition."""
from pathlib import Path
import argparse, collections, gzip, importlib.util, io, json, os, pickle, sys, sysconfig, time

def partitions(n, prefix=()):
    if len(prefix) == n:
        yield prefix; return
    for label in range(max(prefix, default=-1) + 2):
        yield from partitions(n, prefix + (label,))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--reference',action='store_true');args=ap.parse_args()
    root=Path(__file__).resolve().parents[1];args.output.mkdir(parents=True,exist_ok=False)
    import zoneinfo
    if args.reference:
        import _pydatetime
        sys.modules['datetime']=_pydatetime
        path=Path(sysconfig.get_path('stdlib'))/'zoneinfo/_zoneinfo.py'
        spec=importlib.util.spec_from_file_location('zoneinfo.reference_zoneinfo',path);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);zoneinfo.ZoneInfo=module.ZoneInfo
    from datetime import datetime, timezone
    Z=zoneinfo.ZoneInfo;zoneinfo.reset_tzpath([str(root/'data/tz')]);Z.clear_cache()
    cases=json.loads((root/'data/cases.json').read_text());rules={c['key']:(root/'data/tz'/c['key']).read_bytes() for c in cases}
    def wall(x):return [x.year,x.month,x.day,x.hour,x.minute,x.second,x.microsecond,x.fold]
    def value(row,z):return datetime(*row[:7],fold=row[7],tzinfo=z)
    def profile(v):return [[int((a.replace(fold=1)-b).total_seconds()) for b in v] for a in v]
    def observation(v):return {'profile':profile(v),'wall':[wall(x) for x in v],'offsets':[int(x.utcoffset().total_seconds()) for x in v],'timestamps':[int(x.timestamp()) for x in v]}
    def transport(v,key,scheme):
        if scheme=='grouped_pickle':
            payload=pickle.dumps(v,protocol=5);decoded=pickle.loads(payload)
        elif scheme=='individual_pickle':
            pieces=[pickle.dumps(x,protocol=5) for x in v];payload=json.dumps([x.hex() for x in pieces],separators=(',',':')).encode();decoded=[pickle.loads(bytes.fromhex(x)) for x in json.loads(payload)]
        elif scheme=='by_key_json':
            payload=json.dumps([{'key':key,'wall':wall(x)} for x in v],sort_keys=True,separators=(',',':')).encode();decoded=[value(x['wall'],Z(x['key'])) for x in json.loads(payload)]
        elif scheme=='scope_envelope':
            handles={};rows=[]
            for x in v:
                ident=id(x.tzinfo)
                if ident not in handles:handles[ident]=len(handles)
                rows.append({'handle':handles[ident],'wall':wall(x)})
            payload=json.dumps({'key':key,'handle_count':len(handles),'values':rows},sort_keys=True,separators=(',',':')).encode()
            saved=json.loads(payload)
            fresh=[Z.from_file(io.BytesIO(rules[saved['key']]),key=saved['key']) for _ in range(saved['handle_count'])]
            decoded=[value(x['wall'],fresh[x['handle']]) for x in saved['values']]
        elif scheme=='utc_timestamps':
            payload=json.dumps([int(x.timestamp()) for x in v],separators=(',',':')).encode();decoded=[datetime.fromtimestamp(x,timezone.utc) for x in json.loads(payload)]
        else:raise ValueError(scheme)
        return payload,decoded
    schemes=['grouped_pickle','individual_pickle','by_key_json','scope_envelope','utc_timestamps']
    counts=collections.Counter();groups={};samples=[];start=time.monotonic()
    with gzip.open(args.output/'rows.jsonl.gz','wt',encoding='utf-8',newline='\n') as output:
        for case in cases:
            key=case['key'];probe=datetime(*case['wall'],tzinfo=Z.no_cache(key));gap=int((probe.utcoffset()-probe.replace(fold=1).utcoffset()).total_seconds())
            for constructor in ['primary_cached','no_cache']:
                for n in range(1,7):
                    group={'key':key,'constructor':constructor,'n':n,'gap_seconds':gap,'partitions':0,'distinct_profiles':0,'schemes':{s:collections.Counter() for s in schemes}}
                    profiles=set()
                    for partition in partitions(n):
                        zs=[]
                        for _ in range(max(partition)+1):
                            if constructor=='primary_cached':Z.clear_cache(only_keys=[key]);zs.append(Z(key))
                            else:zs.append(Z.no_cache(key))
                        values=[datetime(*case['wall'],tzinfo=zs[j]) for j in partition]
                        before=observation(values);profiles.add(json.dumps(before['profile']));group['partitions']+=1;counts['tuples']+=1
                        row={'key':key,'constructor':constructor,'n':n,'partition':partition,'gap_seconds':gap,'before':before,'schemes':{}}
                        for scheme in schemes:
                            payload,after=transport(values,key,scheme);got=observation(after)
                            matches={name:got[name]==before[name] for name in before}
                            matches['all_observations']=all(matches.values());counts['transport_trials']+=1
                            for name,ok in matches.items():group['schemes'][scheme][name+'_preserved']+=ok
                            row['schemes'][scheme]={'payload_hex':payload.hex(),'after':got,'matches':matches}
                            if not matches['profile'] and len(samples)<10:samples.append({'key':key,'constructor':constructor,'n':n,'partition':partition,'scheme':scheme,'before':before,'after':got})
                        output.write(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n')
                    group['distinct_profiles']=len(profiles);group['schemes']={k:dict(v) for k,v in group['schemes'].items()};groups[key+'|'+constructor+'|'+str(n)]=group
    summary={'python':sys.version,'implementation':'stdlib_python_reference' if args.reference else 'native_cpython','counts':dict(counts),'groups':groups,'seconds':time.monotonic()-start,'tzpath':'data/tz only; fixed rule files','pickle_protocol':5}
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(args.output/'counterexamples.json').write_text(json.dumps(samples,indent=2)+'\n')
    print(json.dumps({'implementation':summary['implementation'],'counts':dict(counts),'groups':len(groups),'seconds':summary['seconds']}))

if __name__=='__main__':main()
