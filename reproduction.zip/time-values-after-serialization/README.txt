Time values after serialization: reproduction

Requirements
CPython 3.14 on a POSIX system. The run uses both the C and the pure-Python implementations of datetime and zoneinfo from the standard library.

Command
python3.14 -B reproduce.py

The command makes runs/<UTC timestamp>/ and runs three processes there: code/compute.py with the native modules, code/compute.py --reference with the pure-Python modules, and code/verify.py, which recomputes every profile with integer arithmetic and compares both runs. Each process is limited to 18 CPU seconds (--cpu-limit 120 raises the limit). The processes read only the four TZif files in data/tz; the host time zone search path is replaced inside them.

The two summaries are compared with expected.json, ignoring the Python version, the time zone path field and timings. PASS and CHECK.json indicate a full match.

Expected counts
2,224 tuples and 11,120 transports for each implementation; 854,592 profile entries recomputed; sharing partitions of sizes one to six.

Data
data/tz holds the four TZif files and data/cases.json the dates tested. data/NOTICE.txt gives the origin of the rule data.

Files
RESULTS.tsv points from each table to its program, line and output file. ENVIRONMENT.json describes the reference run.
